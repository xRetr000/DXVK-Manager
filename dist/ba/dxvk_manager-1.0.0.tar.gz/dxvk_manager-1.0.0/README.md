# DXVK Manager Tool

A modern cross-platform application for automatically installing and managing DXVK files for your games. DXVK is a Vulkan-based translation layer for Direct3D 9, 10, and 11 that can improve performance and compatibility for many games.

![Python](https://img.shields.io/badge/Python-3.7+-blue.svg)
![PyQt6](https://img.shields.io/badge/GUI-PyQt6-green.svg)
![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux-lightgrey.svg)

## 🚀 Quick Start

**Windows:** Just download `DXVK_Manager.exe` and double-click it! No installation needed.

**Linux:** 
- **Easiest:** `pip3 install dxvk-manager` then run `dxvk-manager`
- **From source:** `python3 dxvk_manager.py`
- **Build executable:** Run `./build.sh`

**Want to build it yourself?**
- **Windows:** Double-click `BUILD.bat` - no terminal needed!
- **Linux:** Run `./build.sh` or `bash build.sh`

See `QUICK_START.md` for detailed instructions.

## Features

🔧 **Core Features:**
- **Modern Dark Mode UI** - Beautiful PyQt6-based interface with Windows 11-inspired design
- Browse and select game folders with an intuitive GUI
- Automatic detection of game architecture (32-bit or 64-bit) by analyzing PE headers
- Smart DirectX version detection (Direct3D 9, 10, or 11) by scanning for existing DLLs
- Automatic download of the latest DXVK release from GitHub (supports both .zip and .tar.gz formats)
- Intelligent installation of the correct DXVK DLLs based on game requirements

🧠 **Advanced Features:**
- Automatic backup of existing DLLs before installation
- Complete installation logging with JSON-based activity records
- Real-time activity log with detailed error messages and tracebacks
- Easy uninstallation with automatic backup restoration
- Manual DirectX version override for edge cases
- Progress tracking and detailed status messages
- Thread-safe operations for smooth UI experience

## Requirements

- **Operating System:** 
  - Windows 10 or Windows 11 (native support)
  - Linux (with Wine support for Windows games)
  - macOS (experimental, requires Wine)
- **Python:** 3.7 or higher (for running from source)
- **Dependencies:** See `requirements.txt`
  - PyQt6 (GUI framework - cross-platform)
  - pefile (PE file analysis - Windows/Wine)
  - pyelftools (ELF file analysis - Linux, optional)
  - requests (HTTP requests for GitHub API)

## Installation

### For End Users (Download and Run)

**Windows:** Just download `DXVK_Manager.exe` and double-click it!  
No installation, no Python, no dependencies needed.

**Linux:** Download the built executable from releases, or build it yourself using the instructions below.

### For Developers (Build from Source)

#### Option 1: Run from Source

1. Clone or download this repository
2. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   python dxvk_manager.py
   ```

#### Option 1b: Install via pip (Recommended for Linux)

**Install from PyPI (if published):**
```bash
pip install dxvk-manager
# Or with Linux support:
pip install "dxvk-manager[linux]"
```

**Install from GitHub:**
```bash
pip install git+https://github.com/yourusername/DXVK-Manager.git
# Or with Linux support:
pip install "git+https://github.com/yourusername/DXVK-Manager.git#egg=dxvk-manager[linux]"
```

**Or install from local source:**
```bash
# Clone the repository
git clone https://github.com/yourusername/DXVK-Manager.git
cd DXVK-Manager

# Install the package
pip install .

# Or install in development mode (editable)
pip install -e .
```

**After installation, run:**
```bash
dxvk-manager
```

### Option 2: Standalone Executable

**Windows - Super Easy Build:**
1. **Double-click `BUILD.bat`**
   - Automatically checks Python, installs dependencies, and builds
   - No terminal needed!
   - Executable: `dist/DXVK_Manager.exe`

**Linux - Build Script:**
1. **Run `./build.sh`** or `bash build.sh`
   - Installs dependencies automatically
   - Builds standalone executable
   - Executable: `dist/DXVK_Manager`

**Executable Details:**
- Size: ~20-50 MB (includes everything needed)
- Standalone: No Python or dependencies required!
- Cross-platform: Works on Windows and Linux

**For detailed instructions, see `README_BUILD.md`**

**Want to create a professional installer?** See `INSTALLER_GUIDE.md`

## Linux Support

### Linux Installation

DXVK Manager works on Linux to install DXVK for Windows games running under Wine. This is especially useful for:
- Non-Steam games running in Wine
- Custom Wine prefixes
- Games that need manual DXVK installation

**Note:** Steam games typically use Proton which includes DXVK automatically. This tool is mainly for non-Steam games or custom setups.

### Prerequisites for Linux

1. **Python 3.7+** (usually pre-installed)
   ```bash
   python3 --version  # Check if installed
   ```

2. **Wine** (for running Windows games)
   ```bash
   # Ubuntu/Debian
   sudo apt install wine
   
   # Fedora
   sudo dnf install wine
   
   # Arch Linux
   sudo pacman -S wine
   ```

3. **Required Python packages:**
   ```bash
   pip3 install -r requirements.txt
   ```

### Running on Linux

#### Option 1: Install via pip (Easiest)

**If published to PyPI:**
```bash
# Simple installation
pip3 install dxvk-manager

# With Linux-specific dependencies (ELF support)
pip3 install "dxvk-manager[linux]"

# Run the application
dxvk-manager
```

**Or install directly from GitHub:**
```bash
# Install from GitHub
pip3 install git+https://github.com/yourusername/DXVK-Manager.git

# Or with Linux-specific dependencies (ELF support)
pip3 install "git+https://github.com/yourusername/DXVK-Manager.git#egg=dxvk-manager[linux]"

# Run the application
dxvk-manager
```

#### Option 2: Run from Source
```bash
# Clone or download the repository
git clone <repository-url>
cd DXVK-Manager

# Install dependencies
pip3 install -r requirements.txt

# Run the application
python3 dxvk_manager.py
```

#### Option 3: Install Locally via pip
```bash
# Clone the repository
git clone <repository-url>
cd DXVK-Manager

# Install the package
pip3 install .

# Run the application
dxvk-manager
```

#### Option 2: Build Standalone Executable
```bash
# Make build script executable
chmod +x build.sh

# Run build script
./build.sh

# Or use bash directly
bash build.sh

# The executable will be in dist/DXVK_Manager
./dist/DXVK_Manager
```

### Using with Wine Prefixes

On Linux, Windows games run in Wine prefixes. Here's how to use DXVK Manager:

#### Finding Your Wine Prefix

1. **Default Wine prefix:** `~/.wine`
2. **Steam games:** `~/.steam/steam/steamapps/compatdata/<appid>/pfx`
3. **Lutris games:** `~/.local/share/lutris/runners/wine/` or check Lutris settings
4. **Custom prefix:** Check your game's installation location

#### Installing DXVK to a Wine Prefix

1. **Launch DXVK Manager**
2. **Click "Browse"** and navigate to your Wine prefix
3. **Select the game folder** within the prefix:
   - For default prefix: `~/.wine/drive_c/Program Files/YourGame/`
   - For Steam: `~/.steam/steam/steamapps/compatdata/<appid>/pfx/drive_c/Program Files/YourGame/`
4. **The tool will automatically detect:**
   - Game architecture (32-bit or 64-bit)
   - DirectX version (if detectable)
5. **Click "Install DXVK"** to install

#### Example: Installing to a Steam Game

```bash
# Find your Steam game's compatdata folder
# Steam Library -> Right-click game -> Properties -> Local Files -> Browse
# The path will be something like:
# ~/.steam/steam/steamapps/compatdata/1234560/pfx/drive_c/Program Files/GameName/

# In DXVK Manager:
# 1. Browse to: ~/.steam/steam/steamapps/compatdata/1234560/pfx/drive_c/Program Files/GameName/
# 2. Select the folder containing the game's .exe file
# 3. Install DXVK
```

### Linux-Specific Notes

- **File Permissions:** You may need to make the executable file executable:
  ```bash
  chmod +x dist/DXVK_Manager
  ```

- **Wine Prefix Detection:** The tool automatically detects common Wine prefix locations

- **DLL Installation:** DXVK DLLs are installed the same way as on Windows - they go into the game folder within the Wine prefix

- **Backup Location:** Backups are stored in a `dxvk_backup` folder within the game directory

### Linux Troubleshooting

**"No executable files found"**
- Make sure you're selecting the folder containing the game's `.exe` file
- The path should be within a Wine prefix (e.g., `drive_c/Program Files/GameName/`)

**"Permission denied" errors**
- Ensure you have write permissions to the game folder
- You may need to run with appropriate permissions:
  ```bash
  # If needed, run with sudo (use with caution)
  sudo python3 dxvk_manager.py
  ```

**Wine prefix not detected**
- Manually navigate to the game folder within the Wine prefix
- The tool works with any folder path, not just auto-detected prefixes

**Game still doesn't use DXVK**
- Ensure your Wine version supports DXVK (Wine 3.10+)
- Check that Vulkan drivers are installed:
  ```bash
  # Check Vulkan support
  vulkaninfo
  ```
- Verify DXVK DLLs are in the game folder
- Some games may need additional Wine configuration

## Usage

### Basic Installation Process

1. **Launch the Application**
   - Run `python dxvk_manager.py` or use the executable

2. **Select Game Folder**
   - **Windows:** Click "Browse" to select your game's installation folder
   - **Linux:** Click "Browse" to select your game folder within a Wine prefix
   - The folder should contain the main game executable (.exe file)

3. **Review Auto-Detection**
   - The tool will automatically detect:
     - Game architecture (32-bit or 64-bit)
     - DirectX version used by the game
   - If detection fails, you can manually override the DirectX version

4. **Configure Options**
   - **Backup existing DLLs:** Recommended to keep checked for safety
   - **DirectX Override:** Use if auto-detection is incorrect

5. **Install DXVK**
   - Click "Install DXVK" to begin the process
   - Monitor progress in the status area
   - Installation typically takes 30-60 seconds

6. **Launch Your Game**
   - Start your game normally
   - DXVK should now be active (you may see improved performance)

### Uninstalling DXVK

1. Select the same game folder where DXVK was installed
2. Click "Uninstall DXVK"
3. The tool will restore the original DLL files from backup

## How It Works

### Architecture Detection
- **Windows:** Analyzes the PE (Portable Executable) header of your game's main .exe file
- **Linux:** Supports both PE files (Wine/Windows games) and ELF files (native Linux executables)
- Determines if the game is 32-bit or 64-bit to install the correct DXVK binaries

### DirectX Version Detection
The application scans the game folder for existing DirectX DLLs:
- `d3d9.dll` → Direct3D 9
- `d3d10.dll` or `d3d10core.dll` → Direct3D 10/10.1
- `d3d11.dll` → Direct3D 11

**Note:** If DirectX version cannot be detected automatically, you can manually override it using the dropdown menu.

### DXVK Installation
1. Fetches the latest DXVK release information from GitHub API
2. Downloads the release archive (.tar.gz or .zip format)
3. Extracts only the required DLLs (x32 or x64) based on your game's architecture
4. Backs up any existing DirectX DLLs in your game folder (if enabled)
5. Copies the DXVK DLLs to your game folder
6. Verifies the installation was successful
7. Logs the installation details for future reference

**Note:** DXVK releases are downloaded on-demand from GitHub. The application does not bundle DXVK files, ensuring you always get the latest version.

## File Structure

```
dxvk_manager/
├── dxvk_manager.py      # Main application entry point and core logic
├── gui.py               # PyQt6-based modern dark mode user interface
├── platform_utils.py    # Cross-platform OS detection and utilities
├── exe_analyzer.py      # PE/ELF header analysis and DirectX detection
├── github_downloader.py  # DXVK download and extraction (supports .zip and .tar.gz)
├── file_manager.py      # File operations (copy, backup, restore)
├── logger.py            # Installation activity logging (JSON format)
├── requirements.txt     # Python dependencies
├── build_executable.py  # PyInstaller build script (Windows)
├── build.sh             # Build script for Linux
├── BUILD.bat            # Build script for Windows
├── test_modules.py      # Unit tests
├── test_integration.py  # Integration tests
└── README.md           # This documentation
```

## Logging

All DXVK installations are logged to `dxvk_manager_log.json` in the application directory. Each log entry includes:
- Timestamp of installation
- Game folder path
- Detected architecture
- DirectX version
- DXVK version installed

Example log entry:
```json
{
  "timestamp": "2024-01-15T14:30:45.123456",
  "game_path": "C:\\Games\\MyGame",
  "architecture": "64-bit",
  "directx_version": "Direct3D 11",
  "dxvk_version": "v2.3"
}
```

## Troubleshooting

### Common Issues

**"No executable files found in the selected folder"**
- **Windows:** Ensure the folder contains .exe files
- **Linux:** Ensure the folder contains executable files (or select a Wine prefix)
- The folder should contain the main game executable
- Some games may have their executables in subfolders
- On Linux, you can select a Wine prefix directory (e.g., `~/.wine` or Steam's compatdata folders)

**"Not a valid PE file" error**
- The selected .exe file may be corrupted or not a standard Windows executable
- Try selecting a different .exe file if multiple exist
- Some game launchers are not the actual game executable

**"Architecture detection failed"**
- Manually verify if your game is 32-bit or 64-bit
- Check the game's system requirements or documentation
- 64-bit games are more common on modern systems

**Installation fails during download**
- Check your internet connection
- Ensure Windows Defender or antivirus isn't blocking the download
- Check the activity log for detailed error messages
- The application supports both .zip and .tar.gz formats - if one fails, the other will be tried
- Try running the application as administrator

**Game doesn't start after DXVK installation**
- Use the "Uninstall DXVK" feature to restore original files
- Some games may not be compatible with DXVK
- Check game-specific compatibility lists online

### Advanced Troubleshooting

**Multiple .exe files detected**
- The tool will use the first .exe file found
- If this is incorrect, manually verify which is the main game executable
- Some games have separate launcher and game executables

**DirectX version detection is wrong or shows "Not detected"**
- Use the "Override DirectX" dropdown to manually select the correct version
- When in doubt, try "Direct3D 11" first as it's most common for modern games
- Older games (pre-2008) typically use Direct3D 9
- If detection fails, the app will install all available DLLs (d3d9.dll, d3d11.dll, dxgi.dll) when set to "Unknown"

**Backup restoration fails**
- Ensure the game is not running during uninstallation
- Check that you have write permissions to the game folder
- Some games may require administrator privileges

## Performance Tips

- DXVK typically provides the most benefit for older DirectX 9 and 10 games
- Modern DirectX 11 games may see smaller improvements
- Performance gains vary significantly between different games and hardware
- Monitor your game's frame rate before and after installation to measure impact

## Safety Notes

- Always keep the "Backup existing DLLs" option enabled
- Test games after DXVK installation to ensure compatibility
- Keep the original game installation files as an additional backup
- Some antivirus software may flag DXVK DLLs as suspicious (false positive)

## Contributing

This project is open source. Contributions are welcome for:
- Bug fixes and improvements
- Additional DirectX version detection methods
- Enhanced error handling
- UI/UX improvements
- Documentation updates

## License

This tool is provided as-is for educational and personal use. DXVK itself is licensed under the zlib/libpng license. Please respect the licenses of all components.

## Credits

- **DXVK Project:** https://github.com/doitsujin/dxvk
- **PE File Analysis:** [pefile](https://github.com/erocarrera/pefile) library
- **GUI Framework:** [PyQt6](https://www.riverbankcomputing.com/software/pyqt/) - Modern Qt6 bindings for Python
- **Build Tool:** [PyInstaller](https://www.pyinstaller.org/) for creating standalone executables

## Technology Stack

- **Language:** Python 3.7+
- **GUI:** PyQt6 (Qt6 framework) - Cross-platform
- **Platform Support:** Windows (native), Linux (Wine), macOS (experimental)
- **Architecture:** Modular design with separate concerns
- **Threading:** QThread for non-blocking operations
- **File Formats:** Supports .zip and .tar.gz DXVK releases
- **Binary Analysis:** PE files (Windows/Wine) and ELF files (Linux native)

---

**Disclaimer:** This tool modifies game files. While it creates backups, always ensure you have your own backups of important game installations. Use at your own risk.

